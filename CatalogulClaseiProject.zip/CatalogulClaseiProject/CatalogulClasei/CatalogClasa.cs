using System;
using System.Collections.Generic;
using System.Text;

namespace CatalogulClaseiProject.CatalogulClasei
{
	public class CatalogClasa
	{
		List < CarnetDeNote > CarnetDeNoteElevi;
		List <Elevi > Elevi;
		Scoala scoala;
		Clasa clasa;
		float mediaClasei;
		Diriginte diriginte;
	}
}
