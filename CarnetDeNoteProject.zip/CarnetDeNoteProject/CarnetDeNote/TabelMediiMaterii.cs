using System;
using System.Collections.Generic;
using System.Text;

namespace CarnetDeNoteProject.CarnetDeNote
{
	public class TabelMediiMaterii
	{
		List < InregistrareMedie > notePrimite;

		public float CalculMedieAnuala()
		{
			throw new NotImplementedException();
		}

		public float CalculMedieSemestriala()
		{
			throw new NotImplementedException();
		}

		public float CalculMedieTrimestriala()
		{
			throw new NotImplementedException();
		}
	}
}
