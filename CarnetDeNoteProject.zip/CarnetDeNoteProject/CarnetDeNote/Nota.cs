using System;
using System.Collections.Generic;
using System.Text;

namespace CarnetDeNoteProject.CarnetDeNote
{
	public class Nota
	{
		float nota;
		string informatii;
	}
}
