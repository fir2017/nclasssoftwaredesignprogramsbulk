using System;
using System.Collections.Generic;
using System.Text;

namespace CarnetDeNoteProject.CarnetDeNote
{
	public class Inregistrare
	{
		Data data;
		Timp timp;
		Nota nota;
		Semnatura SemnaturaProfesor;
		Semnatura SemnaturaElev;
		Semnatura SemnaturaParinte;
		Materia materia;
	}
}
