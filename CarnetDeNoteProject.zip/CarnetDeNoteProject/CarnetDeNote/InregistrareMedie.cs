using System;
using System.Collections.Generic;
using System.Text;

namespace CarnetDeNoteProject.CarnetDeNote
{
	public class InregistrareMedie
	{
		List <Nota > note;
		float MediaNotelor;
		float MediaNotelorCuTeze;
		Materia materia;
		Profesor profesor;
	}
}
