using System;
using System.Collections.Generic;
using System.Text;

namespace CarnetDeNoteProject.UnitateDeInvatamant
{
	public class Cancelarie
	{
		List < Profesor > profesori;
	}
}
