using System;
using System.Collections.Generic;
using System.Text;

namespace CarnetDeNoteProject.UnitateDeInvatamant
{
	public class Clasa
	{
		int anul;
		Diriginte diriginte;
		Educator educator;
		List <elevi > elevi;
		Orar orar;
	}
}
