using System;
using System.Collections.Generic;
using System.Text;

namespace CarnetDeNoteProject.UnitateDeInvatamant
{
	public class Scoala
	{
		string denumire;
		Adresa adresa;
		Localitate localitate;
		string domeniu;
		Data anulInfintarii;
		int numarDeElevi;
		int numarDeClase;
		int numarDeStudenti;
		int numarDeProfesori;
		int numarDeClase;
		List <Clasa> clase;
	}
}
