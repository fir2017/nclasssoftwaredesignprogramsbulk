using System;
using System.Collections.Generic;
using System.Text;

namespace CarnetDeNoteProject.UnitateDeInvatamant
{
	public class Administratie
	{
		Director director;
		Director directorAdjunct;
		List < Persoana > personal;
	}
}
