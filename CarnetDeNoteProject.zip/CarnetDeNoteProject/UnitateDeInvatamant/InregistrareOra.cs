using System;
using System.Collections.Generic;
using System.Text;

namespace CarnetDeNoteProject.UnitateDeInvatamant
{
	public class InregistrareOra
	{
		Ora ora;
		Data data;
		Timp timp;
		float durataTimp;
	}
}
