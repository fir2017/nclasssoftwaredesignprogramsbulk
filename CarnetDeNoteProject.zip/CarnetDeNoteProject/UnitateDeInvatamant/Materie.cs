using System;
using System.Collections.Generic;
using System.Text;

namespace CarnetDeNoteProject.UnitateDeInvatamant
{
	public class Materie
	{
		string denumireMateria;
		Profesor profesor;
		string informatii;
	}
}
