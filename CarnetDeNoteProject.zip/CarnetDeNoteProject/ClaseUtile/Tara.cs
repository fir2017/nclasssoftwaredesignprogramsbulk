using System;
using System.Collections.Generic;
using System.Text;

namespace CarnetDeNoteProject.ClaseUtile
{
	public class Tara
	{
		string denumireTara;
		string continent;
		Image steag;
		sound Imn;
		text VersuriImn;
		long nrlocuitori;
		long suprafata;
		long densitatepopulatie;
		List < string > limba;
		string capitala;
	}
}
