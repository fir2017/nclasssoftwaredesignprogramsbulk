using System;
using System.Collections.Generic;
using System.Text;

namespace CarnetDeNoteProject.ClaseUtile
{
	public class Judet
	{
		string denumireJudet;
		Tara tara;
		Image steag;
		sound Imn;
		text VersuriImn;
		long nrlocuitori;
		long suprafata;
		long densitatepopulatie;
		List < string > limba;
		string capitala;
	}
}
