using System;
using System.Collections.Generic;
using System.Text;

namespace CarnetDeNoteProject.ClaseUtile
{
	public class Localitate
	{
		string denumire;
		Judet judet;
		long nrlocuitori;
		long suprafata;
		long densitatepopulatie;
		Image steag;
	}
}
