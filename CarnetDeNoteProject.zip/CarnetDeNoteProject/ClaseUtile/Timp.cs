using System;
using System.Collections.Generic;
using System.Text;

namespace CarnetDeNoteProject.ClaseUtile
{
	public class Timp
	{
		int ore;
		int minute;
		int secunde;
		int milisecunde;
	}
}
