using System;
using System.Collections.Generic;
using System.Text;

namespace CarnetDeNoteProject.ClaseUtile
{
	public class Data
	{
		int an;
		int luna;
		int zi;
	}
}
