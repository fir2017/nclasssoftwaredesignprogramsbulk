using System;
using System.Collections.Generic;
using System.Text;

namespace CarnetDeNoteProject.ClaseUtile
{
	public class Adresa
	{
		string strada;
		string numarstrada;
		string bloc;
		string numarbloc;
		string etaj;
		string apartament;
		Localitate localitate;
	}
}
