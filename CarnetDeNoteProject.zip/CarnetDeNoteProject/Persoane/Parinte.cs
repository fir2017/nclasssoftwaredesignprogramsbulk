using System;
using System.Collections.Generic;
using System.Text;

namespace CarnetDeNoteProject.Persoane
{
	public class Parinte
	{
	}
}
