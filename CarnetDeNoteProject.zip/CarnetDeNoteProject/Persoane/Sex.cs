using System;
using System.Collections.Generic;
using System.Text;

namespace CarnetDeNoteProject.Persoane
{
	public enum Sex
	{
		masculin,
		feminin,
		neutru,
		mixt,
		necunoscut,
		indefinit
	}
}
