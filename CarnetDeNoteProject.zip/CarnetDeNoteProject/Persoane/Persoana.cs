using System;
using System.Collections.Generic;
using System.Text;

namespace CarnetDeNoteProject.Persoane
{
	public class Persoana
	{
		string nume;
		string prenume;
		string prenumesecund;
		Persoana Mama;
		Persoana Tata;
		Adresa adresa;
		Data DataNasterii;
		Localitate loculNasterii;
		Sex sexul;
	}
}
